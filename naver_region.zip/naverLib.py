def find_address_codes(address_name, file_path="address_code.txt"):
    address_codes = {}
    
    # 파일을 읽어서 address_codes 딕셔너리 생성
    with open(file_path, 'r', encoding='cp949') as file:
        next(file)  # 첫 줄은 헤더이므로 건너뜁니다.
        for line in file:
            parts = line.strip().split('\t')
            if len(parts) == 3 and parts[2] == '존재':  # 폐지되지 않은 법정동만 포함합니다.
                code, name, _ = parts
                address_codes[name] = code

    # 입력받은 address_name을 포함하는 모든 법정동명과 코드를 찾기
    matching_codes = {name: code for name, code in address_codes.items() if address_name in name}
    
    return matching_codes